using { customers.app as db } from '../db/schema';

using { metadata as external } from './external/metadata';

@requires:'authenticated-user'
service ComplaintsService {

  @cds.redirection.target
  entity Customers as projection on db.Customers;
  
  @restrict: [
    { grant: 'READ', to: 'viewer' },
    { grant: ['READ','CREATE','UPDATE','DELETE'], to: 'admin' }
  ]
  @odata.draft.enabled
  @cds.redirection.target
  entity Complaints as projection on db.Complaints;
  
  @cds.redirection.target
  @readonly entity Employees as projection on external.Employees;

}
