import cds from '@sap/cds';

export default class ComplaintsService extends cds.ApplicationService {

	async init() {

		const {	Employees } = this.entities;

			 this.on('READ', Employees, async (request) => {
				const northwindService = await cds.connect.to('metadata');
				return northwindService.tx(request).run(request.query);
			});
        }
    }