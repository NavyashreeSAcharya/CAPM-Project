sap.ui.define([
    "sap/ui/core/mvc/Controller",
     "sap/ui/core/routing/History" 
], (Controller,History) => {
    "use strict";

    return Controller.extend("complaints.complaints.controller.CreateCustomer", {
        onInit() {
        },
        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                
                this.getOwnerComponent().getRouter().navTo("RouteMainView", {}, true /* true replaces the history state */);
            }
        }
    });
});