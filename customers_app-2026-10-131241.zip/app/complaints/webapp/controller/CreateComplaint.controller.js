sap.ui.define([
    "sap/ui/core/mvc/Controller",
     "sap/ui/core/routing/History" ,
     "sap/m/MessageBox",
     "sap/m/MessageToast"
], (Controller,History,MessageBox,MessageToast) => {
    "use strict";

    return Controller.extend("complaints.complaints.controller.CreateComplaint", {
        onInit: function () {
            // Register a router listener to reset the form every time a user visits this view
            var oRouter = this.getOwnerComponent().getRouter();
            oRouter.getRoute("RouteCreateComplaint").attachPatternMatched(this._onRouteMatched, this);
        },

        _onRouteMatched: function () {
            var oODataModel = this.getOwnerComponent().getModel();
            
            // 1. Create a transient context for a new Complaint row in OData
            // CAPM automatically handles deep compositions if you add nested data later
            this._oContext = oODataModel.createEntry("/Complaints", {
                properties: {
                    status: "Open",
                    // Add other defaults here if needed
                }
            });

            // 2. Bind this brand new empty record to the view layout
            this.getView().setBindingContext(this._oContext);
        },

        onNavBack: function () {
            // 1. Get the global routing history instance
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            // 2. If a previous history state exists, go back via native browser history
            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                // 3. Fallback: If no history exists (e.g. browser refresh), route cleanly back to your main page
                // Replace "RouteMainView" with the exact name of your main route from manifest.json
                this.getOwnerComponent().getRouter().navTo("RouteMainView", {}, true /* true replaces the history state */);
            }
        },

        onSaveComplaint: function(){
            var oView = this.getView();
            var oJSONModel = oView.getModel("complaintModel");
            var oData = oJSONModel.getData();

            //Validate Complaint

            if (!oData.complaintNumber){
                MessageBox.error("Complaint NUmber is required.");
                return
            }
            if (!oData.customer){
                MessageBox.error("Customer is required.");
                return
            }
            if (!oData.category){
                MessageBox.error("Category is required.");
                return
            }
            if (!oData.priority){
                MessageBox.error("Priority is required.");
                return
            }
            if (!oData.subject){
                MessageBox.error("Subject is required.");
                return
            }
            if (!oData.assignedTo){
                MessageBox.error("Assignee is required.");
                return
            }
            if (!oData.status){
                MessageBox.error("Status is required.");
                return
            }
            
            //Create Payload

            var oPayload = {
                complaintNumber: oData.complaintNumber,
                customer: oData.customer,
                category: oData.category,
                priority: oData.priority,
                subject: oData.subject,
                description: oData.description,
                assignedTo: oData.assignedTo,
                status: oData.status || "Open",

                comments: [],
                resolution: null
            };

            //Add Composition entities Comments and Resolution

            if (oData.comments && Array.isArray(oData.comments)){
                oData.comments.forEach(function (oComment){
                    oPayload.comments.push({
                        ID : oComment.ID,
                        comment:oComment.comment,
                        commentedBy: oComment.commentedBy,
                        commentDate: oComment.commentDate
                    });
                });
            }

            if (oData.resolution && oData.resolution.resolvedBy){
                oPayload.resolution = {
                    ID: oData.resolution.ID,
                    resolutionText: oData.resolution.resolutionText,
                    resolvedDate: oData.resolution.resolvedDate,
                    resolvedBy: oData.resolution.resolvedBy
                };
            }

            console.log("Deep Create Complaint Payload:",JSON.stringify(oPayload,null,4));

            //Odata Model

            var oODataModel = this.getOwnerComponent().getModel();

            //Deep Create to CAPM Services

            oODataModel.create("/Complaints",oPayload,{
                success: function (oResponse) {
                    console.log("Complaint Saved Successfully:",oResponse);
                    MessageToast.show("Complaint Details are saved successfully");
                }.bind(this),
                error: function (oError){
                    console.error("Deep Create Failed",oError);
                    var sMessage = "Error while saving Complaint";

                    if (oError.responseText){
                        try {
                            var oErrorData = JSON.parse(oError.responseText);
                            if (oErrorData.error && oErrorData.error.message){
                                sMessage = oErrorData.error.message.value || oErrorData.error.message; 
                            }
                        }catch (e){
                            console.error(e);
                        }
                    }
                    MessageBox.error(sMessage);
                } .bind(this)   
            });
        }
    });
});
