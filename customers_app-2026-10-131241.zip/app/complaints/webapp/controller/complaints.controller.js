sap.ui.define([
    "sap/ui/core/mvc/Controller"
], (Controller) => {
    "use strict";

    return Controller.extend("complaints.complaints.controller.complaints", {
        onInit() {
        },
        onCreateComplaint: function () {
         this.getOwnerComponent().getRouter().navTo("RouteCreateComplaint");
        },
        onCreateCustomer: function () {
         this.getOwnerComponent().getRouter().navTo("RouteCreateCustomer");
        }
    });
});